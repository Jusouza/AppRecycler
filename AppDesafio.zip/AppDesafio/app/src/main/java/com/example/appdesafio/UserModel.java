package com.example.appdesafio;

class UserModel {
    public Object getName() {
        return null;
    }

    public void incrementAge() {

    }

    public Object getAge() {
        return null;
    }
}
